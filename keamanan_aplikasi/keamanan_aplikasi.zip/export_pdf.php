<?php
// Nonaktifkan penampilan error ke layar agar tidak merusak file pdf
ini_set('display_errors', 0);

// Manggil file koneksi, helper, dan class SimplePDF
require_once "config/koneksi.php";
require_once "config/helper.php";
require_once "config/SimplePDF.php";

// Pastikan user sudah login
auth_check();

$user_id = $_SESSION["user_id"];
$username = $_SESSION["username"];

// Ambil parameter ekspor khusus satu transaksi atau filter massal
$id = isset($_GET["id"]) ? trim($_GET["id"]) : "";
$jenis_filter = isset($_GET["jenis"]) ? trim($_GET["jenis"]) : "";
$search = isset($_GET["search"]) ? trim($_GET["search"]) : "";

try {
    if ($id !== "") {
        $query =
            "SELECT t.*, k.nama_kategori, d.nama_dompet FROM transaksi t LEFT JOIN kategori k ON t.id_kategori = k.id_kategori LEFT JOIN dompet d ON t.id_dompet = d.id_dompet WHERE t.id = :id AND t.user_id = :user_id";
        $params = ["id" => $id, "user_id" => $user_id];
    } else {
        $query = "SELECT t.*, k.nama_kategori, d.nama_dompet FROM transaksi t LEFT JOIN kategori k ON t.id_kategori = k.id_kategori LEFT JOIN dompet d ON t.id_dompet = d.id_dompet WHERE t.user_id = :user_id";
        $params = ["user_id" => $user_id];

        if ($jenis_filter === "Pemasukan" || $jenis_filter === "Pengeluaran") {
            $query .= " AND t.jenis = :jenis";
            $params["jenis"] = $jenis_filter;
        }

        if ($search !== "") {
            $query .= " AND t.keterangan LIKE :search";
            $params["search"] = "%" . $search . "%";
        }

        $query .= " ORDER BY t.tanggal DESC, t.id DESC";
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();

    // Hitung ringkasan (Total Pemasukan, Pengeluaran, Saldo) — transfer antar dompet tidak dihitung
    $total_pemasukan = 0;
    $total_pengeluaran = 0;
    foreach ($transactions as $row) {
        if (isset($row["is_transfer"]) && $row["is_transfer"] == 1) {
            continue; // Lewati transaksi transfer antar dompet
        }
        if ($row["jenis"] === "Pemasukan") {
            $total_pemasukan += $row["nominal"];
        } else {
            $total_pengeluaran += $row["nominal"];
        }
    }
    $saldo_sekarang = $total_pemasukan - $total_pengeluaran;
} catch (\PDOException $e) {
    error_log($e->getMessage());
    die("Gagal mengambil data untuk export PDF.");
}

// Tentukan judul laporan dan nama file berkas
if ($id !== "") {
    $title_report = "KUITANSI TRANSAKSI - DOMPETKU";
    $filename = "Kuitansi_Transaksi_" . $id . "_" . date("Ymd_His") . ".pdf";
} else {
    $title_report = "LAPORAN TRANSAKSI - DOMPETKU";
    $filename = "Laporan_Transaksi_DompetKu_" . date("Ymd_His") . ".pdf";
}

// Inisialisasi PDF
$pdf = new SimplePDF();

// 1. Judul Laporan
$pdf->addText(40, 790, $title_report, 16, true, [13, 110, 253]);
$pdf->addText(
    40,
    775,
    "Aplikasi Catatan Keuangan Pribadi yang Aman",
    10,
    false,
    [100, 100, 100],
);

// Garis pembatas header
$pdf->addLine(40, 765, 550, 765, [13, 110, 253], 2.0);

// 2. Informasi Laporan
$pdf->addText(40, 745, "Nama Pengguna : " . $username, 10, true);
$pdf->addText(40, 730, "Tanggal Ekspor : " . date("d M Y H:i:s"), 10, false, [
    80,
    80,
    80,
]);

$filter_text = "Semua Jenis";
if ($jenis_filter !== "") {
    $filter_text = $jenis_filter;
}
if ($search !== "") {
    $filter_text .= " (Cari: \"" . $search . "\")";
}
$pdf->addText(40, 715, "Filter Aktif    : " . $filter_text, 10, false, [
    80,
    80,
    80,
]);

// 3. Header Tabel
// Koordinat Y awal untuk header tabel
$y_header = 680;
// Gambar kotak header berwarna biru (Primary)
$pdf->addRect(40, $y_header, 510, 20, [13, 110, 253]);

// Tulis label header (Warna putih)
$white = [255, 255, 255];
$pdf->addText(45, $y_header + 5, "No", 10, true, $white);
$pdf->addText(70, $y_header + 5, "Tanggal", 10, true, $white);
$pdf->addText(125, $y_header + 5, "Jenis", 10, true, $white);
$pdf->addText(185, $y_header + 5, "Dompet", 10, true, $white);
$pdf->addText(255, $y_header + 5, "Keterangan", 10, true, $white);
$pdf->addText(460, $y_header + 5, "Nominal", 10, true, $white);

// 4. Baris Data
$y_row = 655;
$no = 1;

if (empty($transactions)) {
    $pdf->addText(45, $y_row, "Tidak ada data transaksi.", 10, false, [
        120,
        120,
        120,
    ]);
    $pdf->addLine(40, $y_row - 5, 550, $y_row - 5, [220, 220, 220], 1.0);
    $y_row -= 20;
} else {
    // Batasi jumlah baris agar pas di satu halaman (maksimal 24 transaksi agar ringkasan pas di bawah)
    $max_rows = 24;
    $count = 0;

    foreach ($transactions as $row) {
        if ($count >= $max_rows) {
            $pdf->addText(
                45,
                $y_row,
                "... (data lainnya terpotong, silakan gunakan filter pencarian)",
                9,
                false,
                [120, 120, 120],
            );
            $pdf->addLine(
                40,
                $y_row - 5,
                550,
                $y_row - 5,
                [220, 220, 220],
                1.0,
            );
            $y_row -= 20;
            break;
        }

        // Zebra striping: warna latar belang-belang abu-abu tipis untuk baris genap
        if ($no % 2 === 0) {
            $pdf->addRect(40, $y_row - 4, 510, 18, [248, 249, 250]);
        }

        // Tulis isi kolom
        $pdf->addText(45, $y_row, $no++, 10, false);
        $pdf->addText(
            70,
            $y_row,
            date("d M Y", strtotime($row["tanggal"])),
            10,
            false,
        );

        // Warna jenis
        if ($row["jenis"] === "Pemasukan") {
            $pdf->addText(125, $y_row, "Pemasukan", 10, true, [25, 135, 84]); // Hijau
            $nominal_text = "+" . number_format($row["nominal"], 0, ",", ".");
            $nominal_color = [25, 135, 84];
        } else {
            $pdf->addText(125, $y_row, "Pengeluaran", 10, true, [220, 53, 69]); // Merah
            $nominal_text = "-" . number_format($row["nominal"], 0, ",", ".");
            $nominal_color = [220, 53, 69];
        }

        // Tulis dompet
        $dompet_name = $row["nama_dompet"] ? $row["nama_dompet"] : "Tanpa Dompet";
        if (strlen($dompet_name) > 12) {
            $dompet_name = substr($dompet_name, 0, 10) . "..";
        }
        $pdf->addText(185, $y_row, $dompet_name, 10, false);

        // Potong keterangan jika terlalu panjang agar tidak melewati lebar kolom
        $keterangan = $row["keterangan"];
        if (strlen($keterangan) > 35) {
            $keterangan = substr($keterangan, 0, 33) . "..";
        }

        $pdf->addText(255, $y_row, $keterangan, 10, false);
        $pdf->addText(460, $y_row, $nominal_text, 10, true, $nominal_color);

        // Gambar garis pemisah baris
        $pdf->addLine(40, $y_row - 5, 550, $y_row - 5, [220, 220, 220], 0.5);

        $y_row -= 20;
        $count++;
    }
}

// Spasi tambahan sebelum ringkasan
$y_row -= 10;

// 5. Ringkasan Total
// Gambar box ringkasan dengan latar abu-abu terang
$pdf->addRect(40, $y_row - 50, 510, 55, [233, 236, 239], [200, 200, 200], 1.0);

// Teks Ringkasan
$pdf->addText(50, $y_row - 12, "Total Pemasukan", 10, true);
$pdf->addText(
    200,
    $y_row - 12,
    ": Rp " . number_format($total_pemasukan, 0, ",", "."),
    10,
    true,
    [25, 135, 84],
);

$pdf->addText(50, $y_row - 27, "Total Pengeluaran", 10, true);
$pdf->addText(
    200,
    $y_row - 27,
    ": Rp " . number_format($total_pengeluaran, 0, ",", "."),
    10,
    true,
    [220, 53, 69],
);

$saldo_color = $saldo_sekarang >= 0 ? [13, 110, 253] : [220, 53, 69];
$pdf->addText(50, $y_row - 42, "Saldo Akhir", 10, true);
$pdf->addText(
    200,
    $y_row - 42,
    ": Rp " . number_format($saldo_sekarang, 0, ",", "."),
    10,
    true,
    $saldo_color,
);

// Output berkas PDF ke browser
// Bersihkan semua tingkatan output buffer untuk mencegah kebocoran karakter
while (ob_get_level() > 0) {
    ob_end_clean();
}

header("Content-Type: application/pdf");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

echo $pdf->output();
exit();
